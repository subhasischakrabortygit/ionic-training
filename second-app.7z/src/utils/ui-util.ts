import { LoadingController, ToastController } from "ionic-angular";
import { Injectable } from "@angular/core";

@Injectable()
export class UIUtils{
  private loader: any;
  private toaster: any;

  constructor(public loadingCtrl: LoadingController, 
              public toastCtrl: ToastController) {
    
  }

  presentLoading(_text: string, _duration: number) {
    this.loader = this.loadingCtrl.create({
      content: _text,
      duration: _duration
    });
    this.loader.present();
  }

  dismissLoading(){
    this.loader.dismiss();
  }

  presentToast(_text: string, _duration: number){
    this.toaster = this.toastCtrl.create({
      message: _text,
      duration: _duration
    });
    this.toaster.present();
  }

  dismissToast(){
    this.toaster.dismiss();
  }
}
