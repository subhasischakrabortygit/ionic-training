import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { NgForm } from '@angular/forms';

/*
  Generated class for the PostProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class PostProvider {

  constructor(public http: Http) {
    console.log('Hello PostProvider Provider');
  }

  getPosts(){
    console.log("Inside get Posts");
    return this.http.get("http://jsonplaceholder.typicode.com/posts")
                .pipe(map(resp => {
                  console.log(resp);
                  return resp.json();
                }))
  }

  addPost(post){
    console.log("Inside post Posts");
    return this.http.post("http://jsonplaceholder.typicode.com/posts",post)
    .pipe(map(resp => {
      console.log(resp);
      return resp.json();
    }))

  }

}
