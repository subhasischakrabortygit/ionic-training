import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-checkout',
  templateUrl: 'checkout.html',
})
export class CheckoutPage implements OnInit{


item: string;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    
    this.item=JSON.parse(JSON.stringify(this.navParams.data));
    

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CheckoutPage');
  }

    ngOnInit(){
      console.log(this.navParams);
    }

}
