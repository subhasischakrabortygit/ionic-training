import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import {PostProvider } from '../../providers/post/post';
import { FormPage } from '../form/form';
import { UIUtils } from '../../utils/ui-util';
/**
 * Generated class for the PostsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-posts',
  templateUrl: 'posts.html',
})
export class PostsPage implements OnInit {

  contactData: any;
  post: any;
  constructor(public uiUtil: UIUtils,public loadingCtrl: LoadingController, public toastCtrl: ToastController, public navCtrl: NavController, public navParams: NavParams, public postProvider: PostProvider ) {
  
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PostsPage');
  }

  ngOnInit(){
    
    this.fromProvidersPost();
  }
  fromProvidersPost()
  {
    //this.presentLoading();

    this.uiUtil.presentLoading("Please wait..", 3000)
    
    this.postProvider.getPosts()
     .subscribe( (resp) => {
      console.log(resp);
      if(resp && resp.length > 0)
      {
        this.uiUtil.dismissLoading();
         this.contactData = resp; 
      }
      else{
          this.uiUtil.presentToast("No data found",3000);
      }
  } )}

  


  goToContactForm(){
    this.navCtrl.push(FormPage);
  }


}
