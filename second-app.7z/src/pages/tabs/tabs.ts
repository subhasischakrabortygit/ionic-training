import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PostsPage } from '../posts/posts';
import { FavoritesPage } from '../favorites/favorites';
import { HomePage } from '../home/home';

/**
 * Generated class for the TabsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-tabs',
  templateUrl: 'tabs.html',
})
export class TabsPage {
  postPage: any;
  favoritesPage: any;
  shopsPage: any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    
    this.postPage= PostsPage;
    this.favoritesPage=FavoritesPage;
    this.shopsPage=HomePage;

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TabsPage');
  }

}
