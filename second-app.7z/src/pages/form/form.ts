import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { NgForm } from '@angular/forms';
import { PostProvider } from '../../providers/post/post';
import { UIUtils } from '../../utils/ui-util';
/**
 * Generated class for the FormPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-form',
  templateUrl: 'form.html',
})
export class FormPage {

  constructor(public uiUtil: UIUtils,public navCtrl: NavController,public toastCtrl: ToastController, public navParams: NavParams, public postProvider: PostProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FormPage');
  }

  toProvidersPost( formData: NgForm)  { //1. receive data from comp.html
    console.log(formData);
    //2. send the formData to service
    this.postProvider.addPost(formData.value)
                      .subscribe( (resp) => {  // 3. receiving resp from service
                        console.log(resp);
                        if(resp){
                         console.log(resp.title);
                         formData.reset();
                         this.uiUtil.presentToast("Saved successfully.",3000);
                        }
                        else {
                          this.uiUtil.presentLoading("SOMETHING WENT WRONG", 3000)
                        }
                      })
  }



}
