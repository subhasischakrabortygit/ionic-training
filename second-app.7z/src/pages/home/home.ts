import { Component, OnInit } from '@angular/core';
import { NavController} from 'ionic-angular';
import { CheckoutPage } from '../checkout/checkout';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements OnInit{

  price: number;
  quantity: Array<string>;
  //shopsPage: any;

  constructor(public navCtrl: NavController) {
    //this.shopsPage=HomePage;
  }

  
  goToCheckOut(item :any){


    this.navCtrl.push(CheckoutPage, item);
  }

  ngOnInit(){
    this.quantity = ['1','2','3','4'];
  }

}

